/**
 * Hook customizado para gerenciar criação de estudantes
 */

import { useState, useCallback } from 'react';
import { 
  StudentFormData, 
  StudentCredentials, 
  UseStudentCreationReturn,
  ERROR_MESSAGES 
} from '@/types/student';
import { validateField, sanitizeStudentData } from '@/services/validationService';
import { createStudent, canCreateStudent } from '@/services/studentService';
import { useToast } from '@/hooks/use-toast';

const initialFormData: StudentFormData = {
  fullName: '',
  email: '',
  studentRegistration: '',
};

export function useStudentCreation(): UseStudentCreationReturn {
  const [formData, setFormData] = useState<StudentFormData>(initialFormData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [isValidating, setIsValidating] = useState<Record<string, boolean>>({});
  const [generatedCredentials, setGeneratedCredentials] = useState<StudentCredentials | null>(null);
  const [showCredentials, setShowCredentials] = useState(false);
  const { toast } = useToast();

  const updateField = useCallback((field: keyof StudentFormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
    }));
    
    // Limpar erro do campo quando usuário começar a digitar
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  }, [errors]);

  const validateFieldAsync = useCallback(async (field: keyof StudentFormData) => {
    const value = formData[field];
    
    // Não validar campos vazios em tempo real
    if (!value.trim()) {
      return;
    }

    setIsValidating(prev => ({ ...prev, [field]: true }));
    
    try {
      const error = await validateField(field, value, formData);
      
      setErrors(prev => {
        const newErrors = { ...prev };
        if (error) {
          newErrors[field] = error;
        } else {
          delete newErrors[field];
        }
        return newErrors;
      });
    } catch (error) {
      console.error(`Erro ao validar campo ${field}:`, error);
      setErrors(prev => ({
        ...prev,
        [field]: ERROR_MESSAGES.networkError,
      }));
    } finally {
      setIsValidating(prev => ({ ...prev, [field]: false }));
    }
  }, [formData]);

  const createStudentAsync = useCallback(async () => {
    setIsLoading(true);
    setErrors({});

    try {
      // Verificar permissões
      const hasPermission = await canCreateStudent();
      if (!hasPermission) {
        toast({
          title: "Erro de Permissão",
          description: ERROR_MESSAGES.permissionDenied,
          variant: "destructive",
        });
        return;
      }

      // Validar todos os campos antes de enviar
      const sanitizedData = sanitizeStudentData(formData);
      
      // Validação básica de campos obrigatórios
      const newErrors: Record<string, string> = {};
      
      if (!sanitizedData.fullName) {
        newErrors.fullName = ERROR_MESSAGES.required;
      }
      
      if (!sanitizedData.email) {
        newErrors.email = ERROR_MESSAGES.required;
      }
      
      if (!sanitizedData.studentRegistration) {
        newErrors.studentRegistration = ERROR_MESSAGES.required;
      }

      if (Object.keys(newErrors).length > 0) {
        setErrors(newErrors);
        return;
      }

      // Criar estudante
      const result = await createStudent(sanitizedData);
      
      if (result.success && result.user) {
        setGeneratedCredentials({
          email: result.user.email,
          temporaryPassword: result.user.temporaryPassword,
          userId: result.user.id,
        });
        setShowCredentials(true);
        
        toast({
          title: "Estudante Criado com Sucesso!",
          description: `${sanitizedData.fullName} foi adicionado ao sistema.`,
        });
        
        // Resetar formulário
        setFormData(initialFormData);
        setErrors({});
      } else {
        toast({
          title: "Erro ao Criar Estudante",
          description: result.error || ERROR_MESSAGES.unknownError,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Erro ao criar estudante:', error);
      toast({
        title: "Erro Inesperado",
        description: ERROR_MESSAGES.unknownError,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [formData, toast]);

  const resetForm = useCallback(() => {
    setFormData(initialFormData);
    setErrors({});
    setIsLoading(false);
    setIsValidating({});
    setGeneratedCredentials(null);
    setShowCredentials(false);
  }, []);

  const closeCredentials = useCallback(() => {
    setShowCredentials(false);
    setGeneratedCredentials(null);
  }, []);

  return {
    formData,
    errors,
    isLoading,
    isValidating,
    generatedCredentials,
    showCredentials,
    updateField,
    validateField: validateFieldAsync,
    createStudent: createStudentAsync,
    resetForm,
    closeCredentials,
  };
}