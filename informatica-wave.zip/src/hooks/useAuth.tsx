import { createContext, useContext, useEffect, useState, useCallback } from 'react';

// --- MOCK DATABASE ---
const MOCK_USERS = {
  'admin@portal.com': { id: '1', email: 'admin@portal.com', password: 'password123', role: 'admin', fullName: 'Admin Geral', registration: null },
  'teacher@portal.com': { id: '2', email: 'teacher@portal.com', password: 'password123', role: 'teacher', fullName: 'Prof. Carvalho', registration: null },
  'student@portal.com': { id: '3', email: 'student@portal.com', password: 'password123', role: 'student', fullName: 'Alice Aluna', registration: '2024INFO001' },
};
// --- END MOCK DATABASE ---

export interface UserProfile {
  id: string;
  user_id: string;
  full_name: string;
  email: string;
  student_registration?: string | null;
  created_at: string;
  updated_at: string;
}

export type UserRole = 'admin' | 'student' | 'teacher';

interface AuthContextType {
  user: { id: string; email: string } | null;
  profile: UserProfile | null;
  userRole: UserRole | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  isAdmin: boolean;
  isStudent: boolean;
  isTeacher: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [loading, setLoading] = useState(true);

  const setUserData = useCallback((mockUser: typeof MOCK_USERS[keyof typeof MOCK_USERS] | null) => {
    if (!mockUser) {
      setUser(null);
      setProfile(null);
      setUserRole(null);
      localStorage.removeItem('session');
      return;
    }

    const userData = { id: mockUser.id, email: mockUser.email };
    const profileData: UserProfile = {
      id: mockUser.id,
      user_id: mockUser.id,
      full_name: mockUser.fullName,
      email: mockUser.email,
      student_registration: mockUser.registration,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    setUser(userData);
    setProfile(profileData);
    setUserRole(mockUser.role as UserRole);
    localStorage.setItem('session', JSON.stringify({ user: userData }));
  }, []);

  useEffect(() => {
    const checkSession = () => {
      setLoading(true);
      try {
        const sessionData = localStorage.getItem('session');
        if (sessionData) {
          const parsedSession = JSON.parse(sessionData);
          const loggedInUserEmail = parsedSession.user?.email;
          const mockUser = loggedInUserEmail ? MOCK_USERS[loggedInUserEmail as keyof typeof MOCK_USERS] : null;
          if (mockUser) {
            setUserData(mockUser);
          }
        }
      } catch (error) {
        console.error("Failed to parse session:", error);
        localStorage.removeItem('session');
      } finally {
        setLoading(false);
      }
    };
    checkSession();
  }, [setUserData]);

  const signIn = async (email: string, password: string): Promise<{ error: string | null }> => {
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay

    const mockUser = MOCK_USERS[email as keyof typeof MOCK_USERS];

    if (mockUser && mockUser.password === password) {
      setUserData(mockUser);
      setLoading(false);
      return { error: null };
    } else {
      setLoading(false);
      return { error: 'Credenciais inválidas.' };
    }
  };

  const signOut = async () => {
    setUserData(null);
  };

  const value = {
    user,
    profile,
    userRole,
    loading,
    signIn,
    signOut,
    isAdmin: userRole === 'admin',
    isStudent: userRole === 'student',
    isTeacher: userRole === 'teacher',
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
