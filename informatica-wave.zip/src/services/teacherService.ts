// Mock data - substitua pela sua lógica de API real

// Supondo que essas interfaces/tipos existam em algum lugar
interface Subject {
  id: number;
  name: string;
}

interface Grade {
  id: number;
  studentName: string;
  value: number;
}

interface Absence {
  id: number;
  studentName: string;
  date: string;
  present: boolean;
}

const MOCK_SUBJECTS: Subject[] = [
  { id: 1, name: 'Desenvolvimento Web' },
  { id: 2, name: 'Banco de Dados' },
  { id: 3, name: 'Redes de Computadores' },
];

const MOCK_GRADES: Record<number, Grade[]> = {
  1: [
    { id: 1, studentName: 'Alice', value: 8.5 },
    { id: 2, studentName: 'Beto', value: 9.0 },
  ],
  2: [
    { id: 3, studentName: 'Carlos', value: 7.0 },
    { id: 4, studentName: 'Daniela', value: 6.5 },
  ],
  3: [],
};

const MOCK_ABSENCES: Record<number, Absence[]> = {
  1: [
    { id: 1, studentName: 'Alice', date: '2023-10-01', present: true },
    { id: 2, studentName: 'Beto', date: '2023-10-01', present: false },
  ],
  2: [
    { id: 3, studentName: 'Carlos', date: '2023-10-02', present: true },
  ],
  3: [],
};

export const getSubjectsByTeacher = async (teacherId: number): Promise<Subject[]> => {
  console.log(`Buscando matérias para o professor ID: ${teacherId}`);
  // Simula uma chamada de API
  await new Promise(resolve => setTimeout(resolve, 500));
  return MOCK_SUBJECTS;
};

export const getGradesBySubject = async (subjectId: number): Promise<Grade[]> => {
  console.log(`Buscando notas para a matéria ID: ${subjectId}`);
  // Simula uma chamada de API
  await new Promise(resolve => setTimeout(resolve, 500));
  return MOCK_GRADES[subjectId] || [];
};

export const getAbsencesBySubject = async (subjectId: number): Promise<Absence[]> => {
  console.log(`Buscando faltas para a matéria ID: ${subjectId}`);
  // Simula uma chamada de API
  await new Promise(resolve => setTimeout(resolve, 500));
  return MOCK_ABSENCES[subjectId] || [];
};
