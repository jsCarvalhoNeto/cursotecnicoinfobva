/**
 * Serviço para gerenciamento de estudantes (com dados mocados)
 */

import { generateSecurePassword } from './passwordService';
import { sanitizeStudentData, type StudentFormData } from './validationService';

// Mock de um banco de dados em memória
const MOCK_DB = {
  users: [] as any[],
  profiles: [] as any[],
  roles: [] as any[],
  nextUserId: 1,
};

export interface CreateStudentResponse {
  success: boolean;
  user?: {
    id: string;
    email: string;
    temporaryPassword: string;
  };
  error?: string;
}

/**
 * Cria um novo estudante no sistema (Mocado)
 */
export async function createStudent(data: StudentFormData): Promise<CreateStudentResponse> {
  console.log("Criando estudante com dados (mocado):", data);
  await new Promise(resolve => setTimeout(resolve, 500)); // Simula latência da rede

  try {
    const sanitizedData = sanitizeStudentData(data);
    const temporaryPassword = generateSecurePassword({ length: 12 });
    const userId = (MOCK_DB.nextUserId++).toString();

    // Simula inserção no banco de dados
    MOCK_DB.users.push({ id: userId, email: sanitizedData.email, password: "hashed_password_placeholder" });
    MOCK_DB.profiles.push({ user_id: userId, full_name: sanitizedData.fullName, email: sanitizedData.email, student_registration: sanitizedData.studentRegistration, created_at: new Date().toISOString() });
    MOCK_DB.roles.push({ user_id: userId, role: 'student' });

    console.log("Banco de dados mockado após criação:", MOCK_DB);

    return {
      success: true,
      user: {
        id: userId,
        email: sanitizedData.email,
        temporaryPassword,
      },
    };
  } catch (error) {
    console.error('Erro inesperado ao criar estudante (mocado):', error);
    return {
      success: false,
      error: 'Erro interno do sistema simulado. Tente novamente.',
    };
  }
}

/**
 * Busca informações de um estudante pelo ID (Mocado)
 */
export async function getStudentById(userId: string) {
  console.log(`Buscando estudante por ID (mocado): ${userId}`);
  await new Promise(resolve => setTimeout(resolve, 300));

  const profile = MOCK_DB.profiles.find(p => p.user_id === userId);
  if (!profile) {
    throw new Error('Student not found');
  }
  const role = MOCK_DB.roles.find(r => r.user_id === userId);

  return {
    ...profile,
    role: role ? role.role : null,
  };
}

/**
 * Lista todos os estudantes do sistema (Mocado)
 */
export async function getAllStudents() {
  console.log("Buscando todos os estudantes (mocado)...");
  await new Promise(resolve => setTimeout(resolve, 700));

  return MOCK_DB.profiles.map(profile => ({
    ...profile,
    roles: MOCK_DB.roles.filter(role => role.user_id === profile.user_id),
  })).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}

/**
 * Verifica se o usuário atual tem permissão para criar um novo estudante.
 */
export async function canCreateStudent(): Promise<boolean> {
  // Lógica de permissão mocada.
  return true;
}
