/**
 * Modal para criação de novos estudantes
 */

import { useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { StudentModalProps } from '@/types/student';
import { useStudentCreation } from '@/hooks/useStudentCreation';
import StudentForm from './StudentForm';
import CredentialsDisplay from './CredentialsDisplay';

export default function StudentModal({ isOpen, onClose, onSuccess }: StudentModalProps) {
  const {
    formData,
    errors,
    isLoading,
    isValidating,
    generatedCredentials,
    showCredentials,
    updateField,
    validateField,
    createStudent,
    resetForm,
    closeCredentials,
  } = useStudentCreation();

  // Resetar formulário quando modal abrir
  useEffect(() => {
    if (isOpen) {
      resetForm();
    }
  }, [isOpen, resetForm]);

  // Fechar modal e chamar callback de sucesso quando credenciais forem fechadas
  useEffect(() => {
    if (!showCredentials && generatedCredentials) {
      onClose();
      onSuccess();
    }
  }, [showCredentials, generatedCredentials, onClose, onSuccess]);

  const handleClose = () => {
    if (showCredentials) {
      closeCredentials();
    } else {
      resetForm();
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        {showCredentials && generatedCredentials ? (
          <CredentialsDisplay 
            credentials={generatedCredentials} 
            onClose={closeCredentials}
          />
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                  <span className="text-primary font-semibold">+</span>
                </div>
                Novo Estudante
              </DialogTitle>
              <DialogDescription>
                Preencha os dados abaixo para criar uma nova conta de estudante. 
                Uma senha temporária será gerada automaticamente.
              </DialogDescription>
            </DialogHeader>

            <StudentForm
              formData={formData}
              errors={errors}
              isLoading={isLoading}
              isValidating={isValidating}
              onChange={updateField}
              onSubmit={createStudent}
              onValidateField={validateField}
            />
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}